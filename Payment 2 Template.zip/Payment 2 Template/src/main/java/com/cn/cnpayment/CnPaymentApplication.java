package com.cn.cnpayment;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CnPaymentApplication {

	public static void main(String[] args) {
		SpringApplication.run(CnPaymentApplication.class, args);

	}
}
